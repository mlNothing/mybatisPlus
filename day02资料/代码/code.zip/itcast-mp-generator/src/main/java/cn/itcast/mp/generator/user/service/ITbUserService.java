package cn.itcast.mp.generator.user.service;

import cn.itcast.mp.generator.user.entity.TbUser;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author itcast
 * @since 2019-05-09
 */
public interface ITbUserService extends IService<TbUser> {

}
